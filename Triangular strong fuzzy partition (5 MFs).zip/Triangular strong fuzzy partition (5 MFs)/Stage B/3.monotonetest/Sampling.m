clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
%         b = [0.0124 0.0561 -0.1853 0.2500 0.2500
%              0.0080 0.0871 0.1255 0.2500 0.6331
%             -0.0008 0.0668 0.0978 0.1600 -0.6417
%              0.0286 0.0771 0.0766 0.0401 0.1184
%              0.2500 -0.2264 0.2595 0.1340 0.3853];
%train 2

% b=[0.0220 0.0582 0.1481 0.5 0.5
%    0.0110 0.0876 0.0944 0.5 0.5
%   0.0030 0.0652 0.0978 0.1115 0.4427
%   0.0154 0.0759 0.0908 0.0462 -0.0618
%   0.5 -0.2989 0.2701 0.1274 0.3963];


% %train 3
% 
%  b=[0.0278 0.0567 0.0866 0.5000 0.5000
%     0.0169 0.0773 0.1223 0.5000 0.5723
%    -0.0044 0.0738 0.0939 0.1863 -0.5725
%     0.0145 0.0807 0.0903 0.0084 0.1462
%     0.5000 -1.3071 0.2614 0.1534 0.3842];

%train 4
% 
% b=[0.0784 0.0313 0.1576 0.5000 0.5000
%    0.0009 0.0883 0.0962 0.5000 0.1019
%    0.0019 0.0721 0.0833 0.1012 -0.0366
%    0.0605 0.0885 0.0884 0.0678 -0.0341
%    0.5000 -0.2573 0.2623 0.1030 0.7818];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end