function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trimf(x(1), [1 1 4]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trimf(x(1), [1 4  7]);%key in
mf3_x1 = trimf(x(1), [4 7 10]);%key in
mf4_x1 = trimf(x(1), [7 10  13]);%key in
mf5_x1 = trimf(x(1), [10 13  13]);%key in
fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1];%key in

mf1_x2 = trimf(x(2), [235 235  408.75]);%key in
mf2_x2 = trimf(x(2), [235 408.75  582.5]);%key in
mf3_x2 = trimf(x(2), [408.75 582.5  756.25]);%key in
mf4_x2 = trimf(x(2), [582.5 756.25  930]);%key in
mf5_x2 = trimf(x(2), [756.25 930  930]);%key in
fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2];


size_fuzziness=[5,5]; %key in

complete_fuzzyrule=(combvec(1:5', 1:5')'); %key in