clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
%b = [0.0494 0.0792 -0.0880
%     0.0619 0.0825  0.0930
%     0.0375 0.1154  0.1082];
%train 2

 % b=[0.0527 0.0816 0.5000
 %    0.0600 0.0822 0.0794
 %    0.0611 0.1174 0.1120];


% %train 3
   
  % b=[0.0463 0.0850 -0.0671
  %    0.0658 0.0844  0.0837
  %    0.0569 0.1196  0.1044];
 
%train 4
% 
 b=[0.0442 0.0848 -0.0810
    0.0670 0.0783  0.0899
    0.0697 0.1196  0.0639];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end