% a function used to generate Eq. (9)
function y = func1(b,lambda)

global ICONSTR RK

b = b(:);
    
% Define the 16 target values for b:
% train data  1
%   c = [
%     0.0494
%     0.0792
%    -0.0880
%     0.0619
%     0.0825
%     0.0930
%     0.0375
%     0.1154
%     0.1082
% ];

% 2
%     c = [ 
%     0.0527
%     0.0816
%     0.5000
%     0.0600
%     0.0822
%     0.0794
%     0.0611
%     0.1174
%     0.1120
% ];

% 3
 %    c = [
 %    0.0463
 %    0.0850
 %   -0.0671
 %    0.0658
 %    0.0844
 %    0.0837
 %    0.0569
 %    0.1196
 %    0.1044
 % ];

% 4
   c = [
      0.0442
    0.0848
   -0.0810
    0.0670
    0.0783
    0.0899
    0.0697
    0.1196
    0.0639
 ];

fuzzyrule_matrix=[1	1	0
2	1	0
3	1	0
1	2	0
2	2	0
3	2	0
1	3	0
2	3	0
3	3	0
];

k=constraint(fuzzyrule_matrix);

fobj = (b - c)'*(b - c);
ICONSTR1=(k*[b])';

ICONSTR=ICONSTR1;

y = fobj+ (sum(lambda.* max([ICONSTR; -lambda./(2*RK)])) + sum(RK*(max([ICONSTR; -lambda./(2*RK)])).^2));