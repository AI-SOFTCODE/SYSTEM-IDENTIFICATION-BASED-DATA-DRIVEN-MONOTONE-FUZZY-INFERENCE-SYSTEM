function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trimf(x(1), [1 1 3]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trimf(x(1), [1 3 5]);%key in
mf3_x1 = trimf(x(1), [3 5 7]);%key in
mf4_x1 = trimf(x(1), [5 7 9]);%key in
mf5_x1 = trimf(x(1), [7 9 11]);%key in
mf6_x1 = trimf(x(1), [9 11 13]);%key in
mf7_x1 = trimf(x(1), [11 13 13]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1 mf6_x1 mf7_x1];%key in

mf1_x2 = trimf(x(2), [235 235 350.83]);%key in
mf2_x2 = trimf(x(2), [235 350.83 466.66]);%key in
mf3_x2 = trimf(x(2), [350.83 466.66 582.5]);%key in
mf4_x2 = trimf(x(2), [466.66 582.5 698.33]);%key in
mf5_x2 = trimf(x(2), [582.5 698.33 814.16]);%key in
mf6_x2 = trimf(x(2), [698.33 814.16 930] );%key in
mf7_x2 = trimf(x(2), [814.16 930 930]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2 mf6_x2 mf7_x2];


size_fuzziness=[7,7]; %key in

complete_fuzzyrule=(combvec(1:7', 1:7')'); %key in