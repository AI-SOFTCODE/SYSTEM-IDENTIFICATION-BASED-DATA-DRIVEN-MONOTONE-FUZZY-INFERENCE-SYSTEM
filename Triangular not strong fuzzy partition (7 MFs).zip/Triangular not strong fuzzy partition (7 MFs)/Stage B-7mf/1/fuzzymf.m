function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trimf(x(1), [1 1 3]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trimf(x(1), [2 4 6]);%key in
mf3_x1 = trimf(x(1), [5 5.5 7]);%key in
mf4_x1 = trimf(x(1), [6.5 7.5 8.5]);%key in
mf5_x1 = trimf(x(1), [8 9 10]);%key in
mf6_x1 = trimf(x(1), [9.5 10.5 12]);%key in
mf7_x1 = trimf(x(1), [11 13 13]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1 mf6_x1 mf7_x1];%key in

mf1_x2 = trimf(x(2), [235 235 290]);%key in
mf2_x2 = trimf(x(2), [280 310 340]);%key in
mf3_x2 = trimf(x(2), [330 370 410]);%key in
mf4_x2 = trimf(x(2), [400 450 582.5]);%key in
mf5_x2 = trimf(x(2), [530 600 710]);%key in
mf6_x2 = trimf(x(2), [700 770 840] );%key in
mf7_x2 = trimf(x(2), [830 930 930]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2 mf6_x2 mf7_x2];


size_fuzziness=[7,7]; %key in

complete_fuzzyrule=(combvec(1:7', 1:7')'); %key in