clc
clear
load("FISH01.mat");
%%

Sdim = out(:,2:end) - out(:,1:end-1);
Sdim = filout(Sdim);
out = out';
Odim = out(:,2:end) - out(:,1:end-1);
Odim = filout(Odim);
[Sindex, Smon] = montest(Sdim);
[Oindex, Omon] = montest(Odim);

fprintf('Monotone index testing \n');
fprintf(['For x1: %s with monotone index is %.4f \n'], monfunc(Smon), Sindex);
fprintf(['For x2: %s with monotone index is %.4f \n \n'], monfunc(Omon), Oindex);


function s = monfunc(mon)
     if mon == 1
        s = 'Monotonically Increasing function';
     else
        s = 'Monotonically Decreasing function';
     end
end

function [mindex, mon] = montest(dim)
[m n] = size(dim);
mzero = find (dim==0);
minc = find (dim>0);
mdec = find (dim<0);
mzero = size(mzero,1);
minc = size(minc,1);
mdec = size(mdec,1);
    if minc > mdec
       mindex =  (minc + mzero)/(m*n);
       mon = 1;    
    else
       mindex =  (mdec + mzero)/(m*n);
       mon = 2;
    end
end

function out = filout(Ix)
Ix(abs(Ix)<=1e-14) = 0;
out = Ix;
end