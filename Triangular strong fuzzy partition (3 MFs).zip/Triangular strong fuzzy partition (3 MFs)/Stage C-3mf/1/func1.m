% a function used to generate Eq. (9)
function y = func1(b,lambda)

global ICONSTR RK

b = b(:);
    
% Define the 16 target values for b:

% this is the b_update obtained from Stage B different training data set

% train data  1
c = [
   -0.0062
    0.1587
    0.4180
    0.0330
    0.0978
   -0.1012
   -0.0031
    0.1199
    0.2720];

%train data 2
%c is obtained from b_update stage B from train data 2

%train data 3
%c is obtained from b_update stage B from train data 2

%train data 4
%c is obtained from b_update stage B from train data 2

fuzzyrule_matrix=[1	1	0
2	1	0
3	1	0
1	2	0
2	2	0
3	2	0
1	3	0
2	3	0
3	3	0];

k=constraint(fuzzyrule_matrix);

fobj = (b - c)'*(b - c);
ICONSTR1=(k*[b])';

ICONSTR=ICONSTR1;

y = fobj+ (sum(lambda.* max([ICONSTR; -lambda./(2*RK)])) + sum(RK*(max([ICONSTR; -lambda./(2*RK)])).^2));