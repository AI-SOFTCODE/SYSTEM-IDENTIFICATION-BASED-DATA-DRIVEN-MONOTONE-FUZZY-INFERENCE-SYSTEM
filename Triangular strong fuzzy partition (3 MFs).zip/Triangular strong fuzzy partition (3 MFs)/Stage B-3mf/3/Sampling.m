clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
%         b = [0.0124 0.0561 -0.1853 0.2500 0.2500
%              0.0080 0.0871 0.1255 0.2500 0.6331
%             -0.0008 0.0668 0.0978 0.1600 -0.6417
%              0.0286 0.0771 0.0766 0.0401 0.1184
%              0.2500 -0.2264 0.2595 0.1340 0.3853];
%train 2

 b=[0.0052 0.1604 0.5000
    0.0282 0.0988 -0.1334 
    0.0182 0.1188 0.3031];


% %train 3
% 
  % b=[-0.0016 0.1486 0.4663
  %   0.0364 0.0988 -0.1188
  %   0.0104 0.1316 0.2791];

%train 4
% 
 % b=[-0.0204 0.1819 0.0355
 %    0.0461 0.0838 0.0376
 %    0.0488 0.1437 0.0351];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end