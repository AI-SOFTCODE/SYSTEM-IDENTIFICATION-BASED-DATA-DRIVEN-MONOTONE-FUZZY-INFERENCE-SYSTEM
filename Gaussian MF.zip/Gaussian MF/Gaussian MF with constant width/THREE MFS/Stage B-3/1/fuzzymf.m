function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)


mf1_x1 = gaussmf(x(1), [1 1]);   
mf2_x1 = gaussmf(x(1), [1 7]);  
mf3_x1 = gaussmf(x(1), [1 13]);  
fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1];%key in

mf1_x2 = gaussmf(x(2), [100 235]); 
mf2_x2 = gaussmf(x(2), [100 582.5]); 
mf3_x2 = gaussmf(x(2), [100 930]); 

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2];

size_fuzziness=[3,3]; %key in

complete_fuzzyrule=(combvec(1:3', 1:3')'); %key in