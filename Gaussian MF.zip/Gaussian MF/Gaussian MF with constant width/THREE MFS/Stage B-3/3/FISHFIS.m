function fuzzy_rpn_score = FISHFIS(x1,x2,b)
           
mf1_x1 = gaussmf(x1, [1 1]);   
mf2_x1 = gaussmf(x1, [1 7]);  
mf3_x1 = gaussmf(x1, [1 13]);

mf_x1 = [mf1_x1, mf2_x1, mf3_x1];

mf1_x2 = gaussmf(x2, [100 235]); 
mf2_x2 = gaussmf(x2, [100 582.5]); 
mf3_x2 = gaussmf(x2, [100 930]); 

mf_x2 = [mf1_x2, mf2_x2, mf3_x2];

fir = mf_x1.*mf_x2';
firXconq = fir.*b;
fuzzy_rpn_score = sum(firXconq,"all")/sum(fir,"all");

end


        

                    
                    
                    
