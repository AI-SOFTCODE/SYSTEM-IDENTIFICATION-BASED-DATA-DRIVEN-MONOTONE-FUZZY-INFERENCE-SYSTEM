clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
% b = [0.0337 0.1391 1.4165
%     0.0467 0.1062 -0.0458
%     0.0811 0.1148 0.2168 ];
%train 2

  % b=[0.0476 0.0929 0.9997
  %   0.0463 0.0845 -0.0648
  %   0.0558 0.1130 0.2718];


% %train 3
% % 
  b=[0.0437 0.0835 1.5494
    0.0496 0.0873 -0.0532
    0.0713 0.1221 0.2417];

%train 4
% 
% b=[0.0265 0.1737 0.3839
%     0.0528 0.0959 0.0156
%     0.0001 0.1680 0.0396];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 1
      save("FISH01.mat", "out", "g");

end