clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
  % b =  [0.033   0.120   0.529
  %       0.047   0.120   0.529
  %       0.081   0.120   0.529]; %train 1
%

   b= [0.0457   0.0888   0.4015
       0.0469   0.0894   0.4018
       0.0565   0.1121   0.4020]%train 2


  % b= [0.0437   0.0828   0.5789
  %     0.0495   0.0872   0.5800
  %     0.0710   0.1216   0.5800 ] %train 3

% 
 % b=[0.026   0.135   0.151
 %    0.027   0.135   0.152
 %    0.027   0.151   0.152]%train4


    out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end