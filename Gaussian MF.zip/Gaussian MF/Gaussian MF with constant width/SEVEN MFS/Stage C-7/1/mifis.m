clear all
clc


% Antecedent of the available fuzzy rules
a_avaiable=[1	1	
2	1	
3	1	
4	1	
5	1	
6	1	
7	1	
1	2	
2	2	
3	2	
4	2	
5	2	
6	2	
7	2	
1	3	
2	3	
3	3	
4	3	
5	3	
6	3	
7	3	
1	4	
2	4	
3	4	
4	4	
5	4	
6	4	
7	4	
1	5	
2	5	
3	5	
4	5	
5	5	
6	5	
7	5	
1	6	
2	6
3	6
4	6
5	6
6	6
7	6
1	7
2	7
3	7
4	7
5	7
6	7
7	7]; 

% Consequent of the available fuzzy rule base with respect to the
% antecedent of the available fuzzy rule base
b_avaiable= [     1.1788
  -10.5098
    9.8467
   10.0000
   10.0000
   10.0000
   10.0000
   -1.2629
   12.3176
    8.9260
    9.9999
   10.0000
   10.0000
   10.0000
    0.6911
   -5.9679
    7.2290
    9.9997
   10.0000
   10.0000
   10.0000
   -0.5297
    5.3836
    8.0089
    9.9998
   10.0000
   10.0000
   10.0000
    0.6126
   -4.2019
    9.2843
    9.9999
   10.0000
   10.0000
   10.0000
   -0.5623
    4.3238
    9.6948
   10.0000
   10.0000
   10.0000
   10.0000
    1.6652
   -7.8789
    9.8366
   10.0000
   10.0000
   10.0000
   10.0000
];

min_b=min(b_avaiable);
max_b=max(b_avaiable);

[avai_rule, num_input]=size(a_avaiable);

% all fuzzy rules
a_all=[ 1	1	
2	1	
3	1	
4	1	
5	1	
6	1	
7	1	
1	2	
2	2	
3	2	
4	2	
5	2	
6	2	
7	2	
1	3	
2	3	
3	3	
4	3	
5	3	
6	3	
7	3	
1	4	
2	4	
3	4	
4	4	
5	4	
6	4	
7	4	
1	5	
2	5	
3	5	
4	5	
5	5	
6	5	
7	5	
1	6	
2	6
3	6
4	6
5	6
6	6
7	6
1	7
2	7
3	7
4	7
5	7
6	7
7	7] ;
 


[total_rule, num_input]=size ( a_all);
%least upper bound denoted "lower(a)" and greatest lower bound denoted "upper(a)" are obtained for (3) and (6), respectively
for a= 1:1:total_rule
     ant_a_all=a_all (a,:);
         lower(a)=max_b;
         upper(a)=min_b;
     for b=1:1:avai_rule
         ant_a_avaiable=a_avaiable (b,:);
         if (ant_a_avaiable(1)>=ant_a_all(1) && ant_a_avaiable(2)>=ant_a_all(2))
         lower(a)= min(lower(a), b_avaiable(b));
         end
         if (ant_a_all(1)>=ant_a_avaiable(1) && ant_a_all(2)>=ant_a_avaiable(2))
         upper(a)= max(upper(a), b_avaiable(b));
         end
      end    
end
%greatest lower bound denoted "lower_1(a_1)" and least upper bound denoted "upper_1(a_1)" are obtained for (3) and (6), respectively
for a_1= 1:1:total_rule
     ant_a_all_1=a_all (a_1,:);
         lower_1(a_1)=min_b;
         upper_1(a_1)=max_b;
     for b_1=1:1:avai_rule
         ant_a_avaiable_1=a_avaiable (b_1,:);
         if (ant_a_all_1(1)>=ant_a_avaiable_1(1) && ant_a_all_1(2)>=ant_a_avaiable_1(2)) 
         lower_1(a_1)= max(lower_1(a_1), b_avaiable(b_1));
         end
         if (ant_a_avaiable_1(1)>=ant_a_all_1(1) && ant_a_avaiable_1(2)>=ant_a_all_1(2))
         upper_1(a_1)= min(upper_1(a_1), b_avaiable(b_1));
         end
      end    
end

for j=1:1:total_rule
    b_lower(j)=min(max(lower(j)',min_b),min(lower_1(j)',max_b)); % lower limit(minimum) of both greatest lower bound denoted "lower(a)" and least upper bound denoted "lower_1(a_1)" are obtained, and equation (3) is resulted
    b_upper(j)=max(min(upper(j)',max_b),max(upper_1(j)',min_b)); % upper limit(maximum) of both least upper bound denoted "upper(a)" and greatest lower bound denoted "upper_1(a_1)" are obtained, and equation (6) is resulted
end

interval_valued_fuzzy_rule=(b_lower'+b_upper')/2


