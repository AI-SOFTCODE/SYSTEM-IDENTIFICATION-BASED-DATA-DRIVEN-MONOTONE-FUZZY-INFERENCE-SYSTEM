function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)


mf1_x1 = gaussmf(x(1), [10 46]);%key in %gaussmf %gaussmf %gbellmf
mf2_x1 = gaussmf(x(1), [10 76]);%key in
mf3_x1 = gaussmf(x(1), [10 106]);%key in
mf4_x1 = gaussmf(x(1), [10 136]);%key in
mf5_x1 = gaussmf(x(1), [10 166]);%key in
mf6_x1 = gaussmf(x(1), [10 196]);%key in
mf7_x1 = gaussmf(x(1), [10 230]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1 mf6_x1 mf7_x1];%key in


mf1_x2 = gaussmf(x(2), [400 1613]);%key in
mf2_x2 = gaussmf(x(2), [400 2201]);%key in
mf3_x2 = gaussmf(x(2), [400 2789]);%key in
mf4_x2 = gaussmf(x(2), [400 3377]);%key in
mf5_x2 = gaussmf(x(2), [400 3965]);%key in
mf6_x2 = gaussmf(x(2), [400 4553]);%key in
mf7_x2 = gaussmf(x(2), [400 5140]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2 mf6_x2 mf7_x2];


size_fuzziness=[7,7]; %key in

complete_fuzzyrule=(combvec(1:7', 1:7')'); %key in