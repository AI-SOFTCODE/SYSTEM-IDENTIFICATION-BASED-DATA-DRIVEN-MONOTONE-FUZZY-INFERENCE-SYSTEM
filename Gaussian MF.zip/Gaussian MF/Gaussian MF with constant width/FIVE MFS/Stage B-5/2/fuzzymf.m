function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = gaussmf(x(1), [1 2]);    
mf2_x1 = gaussmf(x(1), [1 4]);    
mf3_x1 = gaussmf(x(1), [1 7]);   
mf4_x1 = gaussmf(x(1), [1 10]);   
mf5_x1 = gaussmf(x(1), [1 13]); 
fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1];%key in

mf1_x2 = gaussmf(x(2), [100 235]); 
mf2_x2 = gaussmf(x(2), [100 408.75]);  
mf3_x2 = gaussmf(x(2), [100 582.5]);  
mf4_x2 = gaussmf(x(2), [100 756.25]); 
mf5_x2 = gaussmf(x(2), [100 930]);  
fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2];


size_fuzziness=[5,5]; %key in

complete_fuzzyrule=(combvec(1:5', 1:5')'); %key in