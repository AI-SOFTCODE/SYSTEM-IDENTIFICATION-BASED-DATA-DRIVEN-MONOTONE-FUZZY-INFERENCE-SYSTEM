clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc

   b =  [-0.163   -0.163   -0.163    2.820    2.820  
         -0.098    0.081    0.109    2.820    2.820  
         -0.098    0.081    0.109    2.820    2.820  
         -0.098    0.109    0.109    2.820    2.820  
          2.820    2.820    2.820    2.820    2.820 ]; %train 1
 
  % b= [-0.048    0.036    0.036    3.695    5.069  
  %     -0.048    0.076    0.112    3.695    5.070  
  %     -0.048    0.076    0.112    3.695    5.070  
  %     -0.048    0.113    0.113    3.695    5.070  
  %      2.966    2.966    2.967    3.695    5.070 ];%train 2

 % b= [-0.051    0.052    0.108    2.764    2.764  
 %     -0.051    0.081    0.108    2.764    2.764  
 %     -0.051    0.081    0.108    2.764     2.764  
 %     -0.051    0.108    0.108    2.764    2.764  
 %      2.764    2.764    2.764    2.764    2.764 ]; %train 3

 % b=[ -0.049    0.018    0.116    2.790    2.790  
 %   -0.049    0.084    0.116    2.790    2.790  
 %   -0.049    0.084    0.116    2.790    2.790  
 %   -0.049    0.116    0.116    2.790    2.790  
 %    2.790    2.790    2.790    2.790    6.627 ];%train4

    out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end