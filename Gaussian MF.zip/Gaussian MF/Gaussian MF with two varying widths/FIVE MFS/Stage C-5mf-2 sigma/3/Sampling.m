clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g =0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc

   % b =  [-0.114    0.009    0.009    2.848    2.848
   %       -0.114    0.055    0.085    2.848    2.848
   %       -0.114    0.055    0.085    2.848    2.848
   %       -0.114    0.055    0.085    2.848    2.848
   %       -0.114    0.055    0.209    2.848    2.848 ]; %train 1
 
  % b= [0.038    0.039    0.086    3.174    3.174
        % 0.038    0.039    0.086    3.174    3.174
        % 0.039    0.039    0.086    3.174    3.174
        % 0.039    0.039    0.086    3.174    3.174
        % 0.039    0.039    0.190    3.174    3.174 ];%train 2

   % b= [-0.418    0.054    0.085    2.835    2.835
 %       -0.418    0.054    0.085    2.835    2.835
 %       -0.418    0.054    0.085    2.835    2.835
 %       -0.418    0.054    0.085    2.835    2.835
 %       -0.418    0.327    0.327    2.835    2.835]; %train 3

   b=[-0.068    0.038    0.092    2.748    2.748
      -0.068    0.092    0.092    2.748    2.748
      -0.068    0.092    0.092    2.748    2.748
      -0.068    0.108    0.108    2.748    2.748
       1.165    1.165    1.165    2.748    2.748 ];%train4

    out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end