clear all
clc

scale=235:1:930;
% scale=1:1:13;

c1=235;
c2=408.75;
c3=582.5;
c4=756.25;
c5=930;
% c1=2;
% c2=4;
% c3=7;
% c4=10;
% c5=13;

sigma1=100;
% sigma2=50;
% sigma1=1;

A1=gaussmf(scale, [sigma1,c1]);
A2=gaussmf(scale, [sigma1,c2]);
A3=gaussmf(scale, [sigma1,c3]);
A4=gaussmf(scale, [sigma1,c4]);
A5=gaussmf(scale, [sigma1,c5]);
plot(scale,[A1; A2; A3; A4; A5]);

E1=-(1/sigma1^2)*scale+(c1/sigma1^2);
figure; plot(scale,E1)
hold all
% 
E2=-(1/sigma1^2)*scale+(c2/sigma1^2);
plot(scale,E2)
hold all

% 
E3=-(1/sigma1^2)*scale+(c3/sigma1^2);
plot(scale,E3)
hold all;

E4=-(1/sigma1^2)*scale+(c4/sigma1^2);
plot(scale,E4)
hold all;

E5=-(1/sigma1^2)*scale+(c5/sigma1^2);
plot(scale,E5)
hold all;