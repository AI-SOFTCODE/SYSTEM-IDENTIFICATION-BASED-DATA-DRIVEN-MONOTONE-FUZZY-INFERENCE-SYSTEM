clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g =0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
%train 1
% b = [0.0453    0.0645   -0.0460    9.9186    8.4966
%     0.0346    0.1059    0.1173    9.9795   -0.3654
%     0.0375    0.0739    0.0926    0.1600   -0.3007
%     0.3325    0.0700    0.0451    0.0060    0.0909
%    -1.0197   -0.0292    0.2089    0.1201    0.3734];
% train 2

 % b=[0.0423    0.0725    0.1497    9.9206    9.9982
 %    0.0339    0.1108    0.0386    9.9915   10.0000
 %    0.0405    0.0703    0.0919    0.1673  -12.6684
 %    0.0542    0.1327    0.0646    0.0212    3.7891
 %    0.1593   -0.3269    0.1899    0.1225    0.3980 ];


% %train 3
 
 % b=[0.0465    0.0621    0.1021    9.8634    8.4877
 %    0.0298    0.0862    0.0886    9.9807   -0.4260
 %    0.0444    0.0788    0.0942    0.1387   -0.2753
 %    0.6716   -0.0106    0.0546   -0.0173    0.0967
 %   -2.8840    0.4381    0.2152    0.1275    0.3736];

%train 4
% % 
 b=[0.0591    0.0380    0.1347    9.9213    8.2911
    0.0217    0.1218    0.0419    9.9917   -1.7858
    0.0375    0.0792    0.0839    0.1088    0.2931
   -0.3883    0.1565    0.0586    0.0503   -0.2176
    3.7024   -0.4447    0.2366    0.0886    0.7354];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 1
      save("FISH01.mat", "out", "g");

end