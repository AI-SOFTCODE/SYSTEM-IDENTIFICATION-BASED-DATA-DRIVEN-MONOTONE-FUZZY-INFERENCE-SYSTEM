function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)


mf1_x1 = gaussmf(x(1), [15 20]);%key in %gaussmf %gaussmf %gbellmf
mf2_x1 = gaussmf(x(1), [15 30]);%key in
mf3_x1 = gaussmf(x(1), [10 50]);%key in
mf4_x1 = gaussmf(x(1), [10 70]);%key in
mf5_x1 = gaussmf(x(1), [10 90]);%key in
mf6_x1 = gaussmf(x(1), [10 110]);%key in
mf7_x1 = gaussmf(x(1), [10 130]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1 mf6_x1 mf7_x1];%key in


mf1_x2 = gaussmf(x(2), [80 235]);%key in
mf2_x2 = gaussmf(x(2), [80 351]);%key in
mf3_x2 = gaussmf(x(2), [50 467]);%key in
mf4_x2 = gaussmf(x(2), [50 582.5]);%key in
mf5_x2 = gaussmf(x(2), [50 698]);%key in
mf6_x2 = gaussmf(x(2), [50 814]);%key in
mf7_x2 = gaussmf(x(2), [50 930]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2 mf6_x2 mf7_x2];


size_fuzziness=[7,7]; %key in

complete_fuzzyrule=(combvec(1:7', 1:7')'); %key in