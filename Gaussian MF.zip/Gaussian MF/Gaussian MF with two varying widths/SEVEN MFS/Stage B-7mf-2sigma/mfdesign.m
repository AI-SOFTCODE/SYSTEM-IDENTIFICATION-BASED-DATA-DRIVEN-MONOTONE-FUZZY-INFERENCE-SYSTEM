clear all
clc
% scale=10:1:130;
scale=235:1:930;

% c1=10;
% c2=30;
% c3=50;
% c4=70;
% c5=90;
% c6=110;
% c7=130;
c1=235;
c2=351;
c3=467;
c4=582.5;
c5=698;
c6=814;
c7=930;
 
% sigma1=10;
% sigma2=15;
sigma1=50;
sigma2=80;

A1=gaussmf(scale, [sigma2,c1]);
A2=gaussmf(scale, [sigma2,c2]);
A3=gaussmf(scale, [sigma1,c3]);
A4=gaussmf(scale, [sigma1,c4]);
A5=gaussmf(scale, [sigma1,c5]);
A6=gaussmf(scale, [sigma1,c6]);
A7=gaussmf(scale, [sigma1,c7]);

plot(scale,[A1; A2; A3;A4;A5;A6;A7]) % ;A4;A5;A6;A7;A8;A9;A10;A11

E1=-(1/sigma1^2)*scale+(c1/sigma2^2);
figure; plot(scale,E1)
hold all
% 
E2=-(1/sigma1^2)*scale+(c2/sigma2^2);
plot(scale,E2)
hold all

% 
E3=-(1/sigma1^2)*scale+(c3/sigma1^2);
plot(scale,E3)
hold all;

% 
E4=-(1/sigma1^2)*scale+(c4/sigma1^2);
plot(scale,E4)
hold all;

% 
E5=-(1/sigma1^2)*scale+(c5/sigma1^2);
plot(scale,E5)
hold all;

% 
E6=-(1/sigma1^2)*scale+(c6/sigma1^2);
plot(scale,E6)
hold all;

% 
E7=-(1/sigma1^2)*scale+(c7/sigma1^2);
plot(scale,E7)
hold all;