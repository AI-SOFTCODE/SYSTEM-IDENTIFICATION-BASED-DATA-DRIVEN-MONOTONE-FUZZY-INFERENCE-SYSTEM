clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g =0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
    b =  [0.047    0.076    0.298
               0.047    0.086    0.298
               3.506    3.506    3.506]; %train 1


     % b= [0.046    0.089    4.098
     %     0.047    0.089    4.098
     %     4.098    4.098    4.098];%train 2


    % b= [0.043    0.083    0.385
    %     0.050    0.087    0.385
    %     3.507    3.507    3.507] %train 3

 
   % b=[0.0426    0.0906    0.4201
   %    0.0492    0.0906    0.4202
   %    3.5618    3.5618    3.5619];%train4


    out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end