clear all
clc

%% STEP 1: Input Your Entire Dataset Directly

data =[6	740	0.11
2	430	0.016
4	490	0.07
4	455	0.2
4	525	0.07
5	490	0.07
3	520	0.024
11	740	0.03
5	710	0.06
5	550	0.072
2	460	0.026
7	615	0.13
4	540	0.07
4	367	0.05
9	710	0.09
4	519	0.09
6	700	0.05
4	570	0.08
8	660	0.16
7	590	0.07
8	670	0.07
5	580	0.14
4	680	0.108
5	525	0.06
5	436	0.05
2	520	0.026
4	485	0.03
8	650	0.04
7	665	0.04
3	490	0.034
4	570	0.08
4	740	0.069
3	570	0.05
10	710	0.05
4	590	0.04
7	580	0.04
4	500	0.04
8	710	0.07
9	650	0.03
3	580	0.022
3	385	0.07
8	780	0.09
4	399	0.12
2	490	0.04
4	600	0.04
4	570	0.075
5	520	0.06
3	235	0.03
1	430	0.021
5	470	0.08
6	330	0.13
3	525	0.072
5	620	0.07
3	550	0.13
3	530	0.03
4	620	0.08
3	285	0.05
6	600	0.06
4	540	0.09
5	500	0.05
1	385	0.023
4	530	0.03
5	680	0.09
4	545	0.08
3	495	0.083
5	615	0.07
6	640	0.15
6	640	0.09
4	645	0.15
6	750	0.06
4	445	0.05
5	500	0.04
2	440	0.013
6	535	0.07
3	610	0.06
3	290	0.07
3	610	0.053
2	430	0.03
2	310	0.05
6	625	0.09
2	455	0.015
10	685	0.04
2	480	0.03
5	530	0.08
7	650	0.05
4	640	0.06
5	485	0.05
2	405	0.024
9	715	0.06
3	545	0.048
9	690	0.11
3	505	0.08
4	540	0.07
7	720	0.161
4	390	0.12
2	380	0.07
3	560	0.037
5	505	0.25
6	660	0.13
4	291	0.07
4	655	0.17
3	420	0.04
5	500	0.06
4	560	0.072
7	790	0.2
9	700	0.1
4	585	0.092
7	660	0.1
3	560	0.032
2	260	0.04
10	710	0.07
9	675	0.13
3	520	0.09
4	435	0.04
5	680	0.04
2	435	0.024
6	710	0.06
7	620	0.1
4	610	0.05
5	316	0.04
4	510	0.03
7	750	0.06
3	550	0.039
2	505	0.025
10	850	0.08
6	575	0.03
7	680	0.04
7	760	0.14
2	490	0.019
6	610	0.27
5	640	0.04
3	505	0.1
4	520	0.06
7	720	0.05
3	550	0.1
3	465	0.068
4	570	0.04
7	930	0.25
2	440	0.016
11	730	0.04
4	305	0.05
7	590	0.04
9	635	0.09
4	570	0.09
5	610	0.1
5	390	0.12
4	560	0.06
6	670	0.07
6	510	0.05
4	640	0.23
9	660	0.17
6	670	0.06
7	590	0.12
5	560	0.03
4	665	0.08
5	660	0.123
2	450	0.022
4	585	0.07
5	640	0.14
4	520	0.07
5	560	0.16
6	555	0.12
3	560	0.05
2	400	0.014
4	555	0.05
8	680	0.13
4	470	0.08
6	690	0.06
3	530	0.029
5	650	0.03
3	580	0.06
4	530	0.062
5	520	0.05
7	780	0.1
8	620	0.09
3	540	0.03
2	445	0.025
5	720	0.07
2	400	0.045
4	490	0.06
4	550	0.03
6	530	0.17
6	650	0.09
4	540	0.33
4	310	0.06
4	585	0.04
5	640	0.06
7	640	0.09
4	685	0.06
3	310	0.08
5	530	0.09
4	575	0.11
6	740	0.05
7	620	0.13
4	640	0.08
5	610	0.05
6	580	0.06
2	485	0.024
4	530	0.06
6	600	0.05
3	660	0.07
6	630	0.03
5	580	0.07
5	550	0.07
5	515	0.19
2	435	0.018
4	445	0.08
2	530	0.045
2	500	0.033
3	610	0.026
3	530	0.05
11	730	0.04
5	570	0.07
11	795	0.1
4	680	0.084
4	575	0.07
4	500	0.07
6	540	0.06
4	470	0.08
5	540	0.06
4	330	0.05
6	600	0.06
4	480	0.06
4	570	0.07
13	490	0.037
6	550	0.08
3	520	0.054
5	560	0.05
3	460	0.02
4	610	0.16
3	550	0.021
2	405	0.039
8	680	0.04
3	420	0.055
4	520	0.1
3	575	0.04
5	600	0.102
7	700	0.04
5	540	0.06
2	425	0.025
4	510	0.05
5	570	0.06
5	510	0.07
5	595	0.1
3	440	0.068
4	630	0.06
9	675	0.11
4	535	0.06
3	450	0.067
2	490	0.018
6	525	0.12
7	820	0.12
4	400	0.08
4	381	0.05
7	750	0.12
8	690	0.04
6	575	0.1
4	468	0.06
7	680	0.051
4	580	0.033
4	500	0.05
2	560	0.031
4	410	0.22
3	540	0.04
2	505	0.02
5	515	0.07
5	530	0.06
2	375	0.029
2	415	0.027
5	525	0.09
6	660	0.09
9	700	0.25
7	670	0.04
6	600	0.04
10	780	0.05
4	560	0.05
7	670	0.15
10	730	0.07
9	690	0.03
6	720	0.06
4	470	0.04
5	590	0.11
3	550	0.09
4	530	0.075
8	650	0.09
4	440	0.2
4	590	0.08
9	680	0.03
4	550	0.06
4	415	0.09
4	480	0.04
4	540	0.127
6	640	0.07
5	585	0.08
3	450	0.017
6	590	0.07
4	680	0.04
4	590	0.07
3	540	0.037
5	370	0.07
8	620	0.02
2	465	0.028
6	640	0.05
7	705	0.06
2	390	0.026
3	490	0.05
2	455	0.024
4	620	0.047
3	300	0.06
10	850	0.1
7	780	0.18
5	670	0.08
2	530	0.027
4	690	0.08
2	430	0.096
2	395	0.024
2	490	0.017
5	404	0.04
4	600	0.061
3	370	0.06
4	550	0.04
4	520	0.05
5	770	0.06
5	550	0.07
2	420	0.028
3	505	0.04
6	660	0.04
2	550	0.029
4	510	0.07
2	450	0.011
5	510	0.05
7	560	0.13
5	650	0.063
5	570	0.08
6	820	0.095
6	630	0.08
6	660	0.13
6	500	0.13
5	515	0.09
5	570	0.039
5	710	0.12
2	435	0.02
6	570	0.12
6	640	0.05
5	510	0.04
4	580	0.08
6	640	0.08
4	550	0.1];

nSamples = size(data, 1);  % Total number of observations

%% STEP 2: Shuffle the Dataset and Split into 4 Folds
% Obtain a random permutation of indices for the dataset.
shuffledIdx = randperm(nSamples);

% Set the number of folds.
k = 4;

% Compute an approximate fold size.
foldSize = floor(nSamples / k);

% Store indices for each fold in a cell array.
folds = cell(k, 1);
for i = 1:k
    if i < k
        folds{i} = shuffledIdx((i-1)*foldSize + 1 : i*foldSize);
    else
        % Last fold gets any remaining observations.
        folds{i} = shuffledIdx((i-1)*foldSize + 1 : end);
    end
end

%% STEP 3: Cross Validation Loop with Training/Test Sets and Performance Recording
% Preallocate cells to store training and test sets, and a vector to record performance.
trainSets = cell(k, 1);
testSets  = cell(k, 1);
performance = zeros(k, 1);

fprintf('\n=== Cross Validation Splits and Manual Performance Input ===\n');
for i = 1:k
    % Current fold indices form the test set.
    testIdx = folds{i};
    
    % The training indices are the union of all other folds.
    trainIdx = [];
    for j = 1:k
        if j ~= i
            trainIdx = [trainIdx; folds{j}(:)];
        end
    end
    
    % Extract training and test data from the full dataset.
    trainingData = data(trainIdx, :);
    testingData  = data(testIdx, :);
    
    % Save the sets in cell arrays (if you wish to use them later).
    trainSets{i} = trainingData;
    testSets{i}  = testingData;
    
    % Display the training and test sets for this fold.
    fprintf('\n===== Fold %d =====\n', i);
    fprintf('Training Set:\n');
    disp(trainingData);
    fprintf('Test Set:\n');
    disp(testingData);
    
    % Prompt the user to input the performance metric for this fold.
    performance(i) = input(sprintf('Enter performance metric for fold %d: ', i));
end

%% STEP 4: Compute and Display Overall Performance
avgPerformance = mean(performance);

fprintf('\n=== Cross-Validation Performance Summary ===\n');
for i = 1:k
    fprintf('Fold %d performance: %.4f\n', i, performance(i));
end
fprintf('Mean performance across folds: %.4f\n', avgPerformance);
