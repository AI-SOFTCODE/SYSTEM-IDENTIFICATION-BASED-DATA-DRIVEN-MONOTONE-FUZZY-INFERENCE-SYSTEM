% a function used to generate Eq. (9)
function y = func1(b,lambda)

global ICONSTR RK

b = b(:);
    
% Define the 16 target values for b:
c = [
  0.0476
    0.0765
    0.5922
    0.0463
    0.0857
    0.0037
    9.9929
    0.1517
    0.3721
    ];



fuzzyrule_matrix=[1	1	0
2	1	0
3	1	0
1	2	0
2	2	0
3	2	0
1	3	0
2	3	0
3	3	0
];

k=constraint(fuzzyrule_matrix);

fobj = (b - c)'*(b - c);
ICONSTR1=(k*[b])';

ICONSTR=ICONSTR1;

y = fobj+ (sum(lambda.* max([ICONSTR; -lambda./(2*RK)])) + sum(RK*(max([ICONSTR; -lambda./(2*RK)])).^2));