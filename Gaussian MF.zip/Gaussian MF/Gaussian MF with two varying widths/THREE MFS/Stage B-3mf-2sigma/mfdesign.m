clear all
clc

% scale=235:1:930;
scale=1:0.1:13;

% c1=235;
% c2=582.5;
% c3=930;
c1=1;
c2=7;
c3=13;


% sigma1=100;
% sigma2=50;
sigma1=1;
sigma2=0.5;

A1=gaussmf(scale, [sigma1,c1]);
A2=gaussmf(scale, [sigma1,c2]);
A3=gaussmf(scale, [sigma2,c3]);
plot(scale,[A1; A2; A3]);

E1=-(1/sigma1^2)*scale+(c1/sigma1^2)
figure; plot(scale,E1)
hold all
% 
E2=-(1/sigma1^2)*scale+(c2/sigma1^2)
plot(scale,E2)
hold all

% 
E3=-(1/sigma1^2)*scale+(c3/sigma2^2)
plot(scale,E3)
hold all;