clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
  b = [0.0476    0.0765    0.5922
           0.0463    0.0857    0.0037
           9.9929    0.1517    0.3721];
%train 2

 % b=[0.0476    0.0928    9.9999
 %    0.0464    0.0845   -0.0251
 %    9.9999    0.1473    0.3706];


% %train 3
% % 
 % b=[0.0435    0.0835    0.7773
 %    0.0497    0.0872   -0.0071
 %    9.9851    0.1644    0.3722];

%train 4
% 
 % b=[0.0424 0.0957 0.8523
 %    0.0486 0.0852 -0.0118
 %    9.9864 0.1504 0.5490];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 1
      save("FISH01.mat", "out", "g");

end