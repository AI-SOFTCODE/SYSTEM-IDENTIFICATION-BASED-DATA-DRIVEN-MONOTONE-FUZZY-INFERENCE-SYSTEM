function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trimf(x(1), [1 1 4]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trimf(x(1), [3 5 7]);%key in
mf3_x1 = trimf(x(1), [6 8 9]);%key in
mf4_x1 = trimf(x(1), [7.5 10 12]);%key in
mf5_x1 = trimf(x(1), [10 13 13]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1];%key in

mf1_x2 = trimf(x(2), [235 235  450]);%key in
mf2_x2 = trimf(x(2), [380 480  582.5]);%key in
mf3_x2 = trimf(x(2), [500 610 720]);%key in
mf4_x2 = trimf(x(2), [660 770 880]);%key in
mf5_x2 = trimf(x(2), [870 930 930]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2];


size_fuzziness=[5,5]; %key in

complete_fuzzyrule=(combvec(1:5', 1:5')'); %key in