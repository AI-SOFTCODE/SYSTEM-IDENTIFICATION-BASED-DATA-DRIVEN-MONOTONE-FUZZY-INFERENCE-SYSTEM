clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
        b =  [0.043    0.067    0.252    0.283    0.283
              0.043    0.081    0.252    0.283    0.283
              0.048    0.081    0.252    0.283    0.283
              0.252    0.252    0.252    0.283    0.283
              0.285    0.285    0.285    0.285    0.370]; %train 1
% 
          % b= [0.043    0.078    0.256    0.292    0.365
          %     0.044    0.079    0.256    0.292    0.365
          %     0.048    0.080    0.256    0.292    0.365
          %     0.255    0.255    0.256    0.292    0.365
          %     0.381    0.381    0.381    0.399    0.400];%train 2

         % b= [0.045    0.072    0.174    0.280    0.280
         %     0.045    0.081    0.174    0.280    0.280
         %     0.051    0.084    0.174    0.280    0.280
         %     0.227    0.227    0.227    0.280    0.280
         %     0.285    0.285    0.285    0.285    0.370]; %train 3

           % b=[0.041    0.077    0.250    0.278    0.278
           %    0.041    0.078    0.250    0.278    0.278
           %    0.054    0.081    0.250    0.278    0.278
           %    0.251    0.251    0.251    0.278    0.278
           %    0.416    0.416    0.416    0.500    0.500];%train4

    out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end