clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
b = [0.0458    0.0672    0.5000    0.5000    0.5000
     0.0401    0.0843    0.2546    0.5000    0.0370
     0.0476    0.0780    0.0859    0.1129    0.5000
     0.5000    0.0715    0.1008    0.0782    0.0328
     0.5000    0.5000    0.2501   -0.1110    0.3700];
%train 2

 % b=[0.0457    0.0783    0.5000    0.5000    0.5000
 %    0.0413    0.0808    0.2613    0.5000    0.5000
 %    0.0482    0.0783    0.0778    0.0927    0.5000
 %    0.5000    0.0746    0.1183    0.0764   -0.0398
 %    0.5000    0.5000    0.1424    0.4285    0.3700];


% %train 3
% 
 % b=[0.0481    0.0718    0.5000    0.5000    0.5000
 %    0.0415    0.0811   -0.0678    0.5000    0.0370
 %    0.0505    0.0836    0.0901    0.1074    0.5000
 %    0.5000    0.0679    0.1117    0.0686    0.0286
 %    0.5000    0.5000    0.2501   -0.1105    0.3700];

%train 4
% 
 % b=[0.0483    0.0776    0.5000    0.5000    0.5000
 %    0.0347    0.0784    0.2521    0.5000    0.0370
 %    0.0546    0.0816    0.0746    0.0969    0.5000
 %    0.5000    0.0693    0.1090    0.0789    0.0129
 %    0.5000    0.5000    0.2500    0.5000    0.5000];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end