function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trapmf(x(1), [1 1 2 3]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x(1), [2 3 4 5]);%key in
mf3_x1 = trapmf(x(1), [4 5 6 7]);%key in
mf4_x1 = trapmf(x(1), [6 7 8 9]);%key in
mf5_x1 = trapmf(x(1), [8 9 10 11]);%key in
mf6_x1 = trapmf(x(1), [10 11 12 12.5]);%key in
mf7_x1 = trapmf(x(1), [12 12.5 13 13]);%key in
fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1 mf6_x1 mf7_x1];%key in

mf1_x2 = trapmf(x(2), [235 235 293 351]);%key in
mf2_x2 = trapmf(x(2), [293 351 409 467]);%key in
mf3_x2 = trapmf(x(2), [409 467 525 582.5]);%key in
mf4_x2 = trapmf(x(2), [525 582.5 609 641]);%key in
mf5_x2 = trapmf(x(2), [609 641 700 757]);%key in
mf6_x2 = trapmf(x(2), [700 757 815 873]);%key in
mf7_x2 = trapmf(x(2), [815 873 930 930]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2  mf6_x2 mf7_x2];


size_fuzziness=[7,7]; %key in

complete_fuzzyrule=(combvec(1:7', 1:7')'); %key in