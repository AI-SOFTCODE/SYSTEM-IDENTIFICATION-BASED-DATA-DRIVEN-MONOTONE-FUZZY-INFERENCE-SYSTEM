% the central finite difference method
function deriv = grad_vec(b,delb)
xvec = b;
xvec1 = b;
for i = 1:length(b)
    xvec = b;
    xvec1 = b;
    xvec(i) = b(i) + delb;
    xvec1(i) = b(i) - delb;
    deriv(i) = (func11(xvec)-func11(xvec1))/(2*delb);
end

