function fuzzy_rpn_score = FISHFIS(x1,x2,b)
           
mf1_x1 = trapmf(x1, [1 1 2 3]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x1, [2 3 4 5]);%key in
mf3_x1 = trapmf(x1, [4 5 6 7]);%key in
mf4_x1 = trapmf(x1, [6 7 8 9]);%key in
mf5_x1 = trapmf(x1, [8 9 10 11]);%key in
mf6_x1 = trapmf(x1, [10 11 12 12.5]);%key in
mf7_x1 = trapmf(x1, [12 12.5 13 13]);%key in
mf_x1 = [mf1_x1, mf2_x1, mf3_x1, mf4_x1, mf5_x1, mf6_x1, mf7_x1];

mf1_x2 = trapmf(x2, [235 235 293 351]);%key in
mf2_x2 = trapmf(x2, [293 351 409 467]);%key in
mf3_x2 = trapmf(x2, [409 467 525 582.5]);%key in
mf4_x2 = trapmf(x2, [525 582.5 609 641]);%key in
mf5_x2 = trapmf(x2, [609 641 700 757]);%key in
mf6_x2 = trapmf(x2, [700 757 815 873]);%key in
mf7_x2 = trapmf(x2, [815 873 930 930]);%key in
mf_x2 = [mf1_x2, mf2_x2, mf3_x2, mf4_x2, mf5_x2, mf6_x2, mf7_x2];

fir = mf_x1.*mf_x2';
firXconq = fir.*b;
fuzzy_rpn_score = sum(firXconq,"all")/sum(fir,"all");

end


        

                    
                    
                    
