function f =sfis(x1,x2,parameter)

mf1_x1 = trapmf(x1, [1 1 2 3]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x1, [2 3 4 5]);%key in
mf3_x1 = trapmf(x1, [4 5 6 7]);%key in
mf4_x1 = trapmf(x1, [6 7 8 9]);%key in
mf5_x1 = trapmf(x1, [8 9 10 11]);%key in
mf6_x1 = trapmf(x1, [10 11 12 12.5]);%key in
mf7_x1 = trapmf(x1, [12 12.5 13 13]);%key in
mf_x1 = [mf1_x1; mf2_x1; mf3_x1; mf4_x1; mf5_x1; mf6_x1; mf7_x1];

mf1_x2 = trapmf(x2, [235 235 293 351]);%key in
mf2_x2 = trapmf(x2, [293 351 409 467]);%key in
mf3_x2 = trapmf(x2, [409 467 525 582.5]);%key in
mf4_x2 = trapmf(x2, [525 582.5 609 641]);%key in
mf5_x2 = trapmf(x2, [609 641 700 757]);%key in
mf6_x2 = trapmf(x2, [700 757 815 873]);%key in
mf7_x2 = trapmf(x2, [815 873 930 930]);%key in
mf_x2 = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2  mf6_x2 mf7_x2];


mul = zeros(7, 7);
    for i = 1:7
        for j = 1:7
            mul(i,j) = mf_x1(i) * mf_x2(j);
        end
    end

    %--- Normalization Factor ---
    % Sum of all membership degrees for normalization.
    sum_below = sum(mul(:));

    %--- Create Rule Base ---
    % Reshape the parameter vector (length should be 125) into a 5x5x5 rule base.
    rule = reshape(parameter, [7, 7]);

    %--- Weighted Rule Contribution ---
    % Multiply each rule’s consequent by the corresponding membership product.
    mult = rule .* mul;
    % Sum over all rules.
    sum_above = sum(mult(:));

    %--- Final Output ---
    % The crisp output is obtained by the weighted average (defuzzification).
    f = sum_above / sum_below;
end
    
    
    