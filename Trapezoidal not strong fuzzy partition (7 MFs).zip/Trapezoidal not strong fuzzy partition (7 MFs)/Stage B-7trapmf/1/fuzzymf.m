function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trapmf(x(1), [1 1 2 3]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x(1), [2.5 3 3.5 4]);%key in
mf3_x1 = trapmf(x(1), [3 4 5.5 6]);%key in
mf4_x1 = trapmf(x(1), [5 6.5 7 8]);%key in
mf5_x1 = trapmf(x(1), [7.5 8.5 9 10]);%key in
mf6_x1 = trapmf(x(1), [9.5 10 11 12.5]);%key in
mf7_x1 = trapmf(x(1), [12 12.5 13 13]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1 mf6_x1 mf7_x1];%key in

mf1_x2 = trapmf(x(2), [235 235 270 320]);%key in
mf2_x2 = trapmf(x(2), [300 370 390 420]);%key in
mf3_x2 = trapmf(x(2), [410 460 490 550]);%key in
mf4_x2 = trapmf(x(2), [530 582.5 590 635]);%key in
mf5_x2 = trapmf(x(2), [620 640 684 757]);%key in
mf6_x2 = trapmf(x(2), [730 760 815 873]);%key in
mf7_x2 = trapmf(x(2), [820 880 930 930]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2  mf6_x2 mf7_x2];


size_fuzziness=[7,7]; %key in

complete_fuzzyrule=(combvec(1:7', 1:7')'); %key in