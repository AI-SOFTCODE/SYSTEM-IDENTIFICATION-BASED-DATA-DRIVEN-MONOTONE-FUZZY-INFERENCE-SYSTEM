function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trapmf(x(1), [1 1 3.5 7]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x(1), [3.5 7 8.5 10.5]);%key in
mf3_x1 = trapmf(x(1), [8.5 10.5 13 13]);%key in
fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1];%key in

mf1_x2 = trapmf(x(2), [235 235 375 582.5]);%key in
mf2_x2 = trapmf(x(2), [375 582.5 695 790]);%key in
mf3_x2 = trapmf(x(2), [695 790 930 930]);%key in
fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2];


size_fuzziness=[3,3]; %key in

complete_fuzzyrule=(combvec(1:3', 1:3')'); %key in