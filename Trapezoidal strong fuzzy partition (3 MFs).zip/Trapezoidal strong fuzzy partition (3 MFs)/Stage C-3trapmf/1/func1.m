% a function used to generate Eq. (9)
function y = func1(b,lambda)

global ICONSTR RK

b = b(:);
    
% Define the 16 target values for b:
% train data  1
 % c = [
 %    0.0404
 %    0.1647
 %    0.0389
 %    0.0606
 %    0.0939
 %    0.0356
 %    0.0011
 %    0.1285
 %    0.1421];

% 2
   c = [ 
    
    0.0441
    0.1615
    0.5000
    0.0588
    0.0938
    0.0248
    0.0213
    0.1249
    0.1728
 ];

% 3
%    c = [     0.0396
%     0.1582
%     0.0638
%     0.0640
%     0.0976
%     0.0157
%    -0.0008
%     0.1287
%     0.1610
% 
% ];

% 4
  % c = [
  %    0.0375
  %   0.1757
  %   0.0173
  %   0.0665
  %   0.0857
  %   0.0532
  %  -0.0128
  %   0.1492
  %   0.0624
  % ];

fuzzyrule_matrix=[1	1	0
2	1	0
3	1	0
1	2	0
2	2	0
3	2	0
1	3	0
2	3	0
3	3	0
];

k=constraint(fuzzyrule_matrix);

fobj = (b - c)'*(b - c);
ICONSTR1=(k*[b])';

ICONSTR=ICONSTR1;

y = fobj+ (sum(lambda.* max([ICONSTR; -lambda./(2*RK)])) + sum(RK*(max([ICONSTR; -lambda./(2*RK)])).^2));