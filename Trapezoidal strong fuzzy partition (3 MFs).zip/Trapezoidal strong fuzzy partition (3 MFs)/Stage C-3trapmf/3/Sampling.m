clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc

% b =  [0.034    0.083    0.083
%       0.034    0.083    0.083
%       0.034    0.129    0.142]; %train 1
 
  % b= [0.034    0.083    0.083
  %     0.034    0.083    0.084
  %     0.034    0.129    0.142]%train 2
 
  % b= [0.034    0.084    0.084
  %     0.034    0.084    0.084
  %     0.034    0.128    0.142] %train 3

    b=[0.030    0.083    0.083
       0.030    0.083    0.083
       0.030    0.106    0.106]%train4

    out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end