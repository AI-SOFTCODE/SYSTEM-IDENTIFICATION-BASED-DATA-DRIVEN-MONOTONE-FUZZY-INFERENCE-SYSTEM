clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
b = [0.0404 0.1647 0.0389
    0.0606 0.0939 0.0356
    0.0011 0.1285 0.1421];
%train 2

 % b=[0.0441 0.1615 0.5000
 %    0.0588 0.0938 0.0248
 %    0.0213 0.1249 0.1728];


% %train 3
 
 % b=[0.0396 0.1582 0.0638
 %    0.0640 0.0976 0.0157
 %   -0.0008 0.1287 0.1610];

%train 4
% 
 % b=[0.0375 0.1757 0.0173
 %    0.0665 0.0857 0.0532
 %    -0.0128 0.1492 0.0624];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end