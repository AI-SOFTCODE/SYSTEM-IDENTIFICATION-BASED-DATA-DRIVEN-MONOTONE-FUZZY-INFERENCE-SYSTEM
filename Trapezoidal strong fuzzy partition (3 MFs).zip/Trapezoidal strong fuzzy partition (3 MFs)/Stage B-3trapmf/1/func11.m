% a function used to generate Eq. (9)
function y = func11(b)

SS=load('sse1.mat');
A=struct2array(SS);


fobj=[b 1]*A*[b 1]';


y = fobj;

% % root mean square error
% 
% n=21;
% y = sqrt(fobj/n);