function f =sfis(x1,x2,parameter)

mf1_x1 = trapmf(x1, [1 1 2.5 4]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x1, [3 5 6 8]);%key in
mf3_x1 = trapmf(x1, [7 8.5 9 10]);%key in
mf4_x1 = trapmf(x1, [9.5 10.5 11.5 12]);%key in
mf5_x1 = trapmf(x1, [11 11.5 13 13]);%key in

mf_x1 = [mf1_x1; mf2_x1; mf3_x1; mf4_x1; mf5_x1];

mf1_x2 = trapmf(x2, [235 235 270 300]);%key in
mf2_x2 = trapmf(x2, [290 320 400 440]);%key in
mf3_x2 = trapmf(x2, [430 470 500 550]);%key in
mf4_x2 = trapmf(x2, [530 582.5 640 790]);%key in
mf5_x2 = trapmf(x2, [768 882 930 930]);%key in

mf_x2 = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2];

mul = zeros(5, 5);
    for i = 1:5
        for j = 1:5
            mul(i,j) = mf_x1(i) * mf_x2(j);
        end
    end

    %--- Normalization Factor ---
    % Sum of all membership degrees for normalization.
    sum_below = sum(mul(:));

    %--- Create Rule Base ---
    % Reshape the parameter vector (length should be 125) into a 5x5x5 rule base.
    rule = reshape(parameter, [5, 5]);

    %--- Weighted Rule Contribution ---
    % Multiply each rule’s consequent by the corresponding membership product.
    mult = rule .* mul;
    % Sum over all rules.
    sum_above = sum(mult(:));

    %--- Final Output ---
    % The crisp output is obtained by the weighted average (defuzzification).
    f = sum_above / sum_below;
end
    
    
    