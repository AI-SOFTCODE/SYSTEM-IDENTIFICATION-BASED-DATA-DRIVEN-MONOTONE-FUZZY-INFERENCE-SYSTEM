clear all
clc

%% STEP 1: Input Your Entire Dataset Directly

data =[5	670	0.06
5	460	0.11
5	510	0.05
4	585	0.02
4	520	0.07
2	500	0.02
5	620	0.21
9	800	0.05
9	810	0.09
5	535	0.07
5	500	0.05
7	580	0.13
6	500	0.06
10	690	0.04
5	670	0.05
2	430	0.031
6	680	0.22
5	415	0.13
6	600	0.06
6	570	0.2
5	630	0.05
8	720	0.07
5	360	0.05
5	570	0.08
3	510	0.05
6	530	0.1
4	555	0.04
6	580	0.06
2	235	0.01
5	585	0.08
6	540	0.13
5	377	0.1
8	670	0.21
4	720	0.046
6	530	0.04
5	500	0.1
7	850	0.26
8	720	0.04
8	820	0.08
6	515	0.1
7	620	0.12
5	470	0.09
3	560	0.037
3	575	0.026
3	530	0.04
9	670	0.15
6	710	0.07
4	655	0.06
3	650	0.038
5	580	0.04
4	590	0.057
6	550	0.09
5	550	0.08
7	600	0.11
6	710	0.07
4	378	0.04
9	690	0.04
13	920	0.37
8	670	0.05
3	640	0.06
5	572	0.06
4	500	0.08
4	700	0.07
5	575	0.09
9	660	0.13
5	545	0.12
5	650	0.09
7	595	0.06
4	560	0.08
5	550	0.06
3	470	0.061
2	450	0.025
5	370	0.05
5	550	0.08
4	590	0.05
4	348	0.04
5	680	0.04
4	500	0.07
4	670	0.07
10	860	0.14
6	720	0.11
5	485	0.09
3	430	0.21
5	615	0.03
3	255	0.06
6	540	0.18
6	500	0.19
2	450	0.025
8	830	0.05
6	680	0.04
5	710	0.08
2	450	0.065
5	430	0.08
3	485	0.04
4	300	0.12
8	910	0.19
3	520	0.03
3	480	0.059
5	595	0.06
4	590	0.07
4	510	0.06
4	590	0.06
3	630	0.037
2	430	0.026
3	560	0.04
6	680	0.05
8	670	0.08
5	427	0.03
5	750	0.1
5	650	0.072
7	700	0.11
5	765	0.04
3	530	0.1
3	510	0.05
4	415	0.056
4	610	0.05
5	540	0.06
5	610	0.16
9	730	0.07];

nSamples = size(data, 1);  % Total number of observations

%% STEP 2: Shuffle the Dataset and Split into 4 Folds
% Obtain a random permutation of indices for the dataset.
shuffledIdx = randperm(nSamples);

% Set the number of folds.
k = 4;

% Compute an approximate fold size.
foldSize = floor(nSamples / k);

% Store indices for each fold in a cell array.
folds = cell(k, 1);
for i = 1:k
    if i < k
        folds{i} = shuffledIdx((i-1)*foldSize + 1 : i*foldSize);
    else
        % Last fold gets any remaining observations.
        folds{i} = shuffledIdx((i-1)*foldSize + 1 : end);
    end
end

%% STEP 3: Cross Validation Loop with Training/Test Sets and Performance Recording
% Preallocate cells to store training and test sets, and a vector to record performance.
trainSets = cell(k, 1);
testSets  = cell(k, 1);
performance = zeros(k, 1);

fprintf('\n=== Cross Validation Splits and Manual Performance Input ===\n');
for i = 1:k
    % Current fold indices form the test set.
    testIdx = folds{i};
    
    % The training indices are the union of all other folds.
    trainIdx = [];
    for j = 1:k
        if j ~= i
            trainIdx = [trainIdx; folds{j}(:)];
        end
    end
    
    % Extract training and test data from the full dataset.
    trainingData = data(trainIdx, :);
    testingData  = data(testIdx, :);
    
    % Save the sets in cell arrays (if you wish to use them later).
    trainSets{i} = trainingData;
    testSets{i}  = testingData;
    
    % Display the training and test sets for this fold.
    fprintf('\n===== Fold %d =====\n', i);
    fprintf('Training Set:\n');
    disp(trainingData);
    fprintf('Test Set:\n');
    disp(testingData);
    
    % Prompt the user to input the performance metric for this fold.
    performance(i) = input(sprintf('Enter performance metric for fold %d: ', i));
end

%% STEP 4: Compute and Display Overall Performance
avgPerformance = mean(performance);

fprintf('\n=== Cross-Validation Performance Summary ===\n');
for i = 1:k
    fprintf('Fold %d performance: %.4f\n', i, performance(i));
end
fprintf('Mean performance across folds: %.4f\n', avgPerformance);


