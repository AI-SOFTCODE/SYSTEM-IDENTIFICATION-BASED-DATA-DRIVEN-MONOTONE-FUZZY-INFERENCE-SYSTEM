function fuzzy_rpn_score = FISHFIS(x1,x2,b)
           
mf1_x1 = trapmf(x1, [1 1 2.5 4]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x1, [3 5 6 8]);%key in
mf3_x1 = trapmf(x1, [7 8.5 9 10]);%key in
mf4_x1 = trapmf(x1, [9.5 10.5 11.5 12]);%key in
mf5_x1 = trapmf(x1, [11 11.5 13 13]);%key in

mf_x1 = [mf1_x1, mf2_x1, mf3_x1, mf4_x1, mf5_x1];

mf1_x2 = trapmf(x2, [235 235 270 300]);%key in
mf2_x2 = trapmf(x2, [290 320 400 440]);%key in
mf3_x2 = trapmf(x2, [430 470 500 550]);%key in
mf4_x2 = trapmf(x2, [530 582.5 640 790]);%key in
mf5_x2 = trapmf(x2, [768 882 930 930]);%key in

mf_x2 = [mf1_x2, mf2_x2, mf3_x2, mf4_x2, mf5_x2];

fir = mf_x1.*mf_x2';
firXconq = fir.*b;
fuzzy_rpn_score = sum(firXconq,"all")/sum(fir,"all");

end


        

                    
                    
                    
