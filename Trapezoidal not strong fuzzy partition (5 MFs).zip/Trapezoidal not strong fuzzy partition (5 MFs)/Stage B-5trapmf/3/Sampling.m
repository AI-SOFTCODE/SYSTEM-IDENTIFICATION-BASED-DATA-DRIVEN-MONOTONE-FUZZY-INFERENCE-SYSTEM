clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
b = [0.0350    0.5000    0.5000    0.5000    0.5000
     0.0500    0.0746    0.5000    0.5000    0.5000
     0.0381    0.0829    0.5000    0.5000    0.0371
     0.0462    0.0790    0.0919    0.0447    0.5000
     0.5000    0.1800    0.0920    0.1006    0.3700];
%train 2

 % b=[0.0433    0.0689    0.5000    0.5000    0.5000
 %    0.0464    0.0817    0.5000    0.5000    0.5000
 %    0.0402    0.0792    0.5000    0.5000    0.5000
 %    0.0476    0.0798    0.0856    0.0478    0.5000
 %    0.5000    0.1744    0.0920    0.1092    0.3700];


% %train 3

 % b=[0.0433    0.0697    0.5000    0.5000    0.5000
 %    0.0478    0.0740    0.5000    0.5000    0.5000
 %    0.0417    0.0820    0.5000    0.5000    0.0371
 %    0.0491    0.0819    0.0947    0.0443    0.5000
 %    0.5000    0.2228    0.0917    0.1066    0.3700];

%train 4
 
 % b=[0.0475    0.0683    0.5000    0.5000    0.5000
 %    0.0402    0.0838    0.5000    0.5000    0.5000
 %    0.0369    0.0784    0.5000    0.5000    0.0370
 %    0.0515    0.0801    0.0886    0.0473    0.5000
 %    0.5000    0.1674    0.0911    0.0887    0.5000];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end