function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trapmf(x(1), [1 1 2.5 4]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trapmf(x(1), [3 5 6 8]);%key in
mf3_x1 = trapmf(x(1), [7 8.5 9 10]);%key in
mf4_x1 = trapmf(x(1), [9.5 10.5 11.5 12]);%key in
mf5_x1 = trapmf(x(1), [11 11.5 13 13]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 mf4_x1 mf5_x1];%key in

mf1_x2 = trapmf(x(2), [235 235 270 300]);%key in
mf2_x2 = trapmf(x(2), [290 320 400 440]);%key in
mf3_x2 = trapmf(x(2), [430 470 500 550]);%key in
mf4_x2 = trapmf(x(2), [530 582.5 640 790]);%key in
mf5_x2 = trapmf(x(2), [768 882 930 930]);%key in

fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 mf4_x2 mf5_x2];


size_fuzziness=[5,5]; %key in

complete_fuzzyrule=(combvec(1:5', 1:5')'); %key in