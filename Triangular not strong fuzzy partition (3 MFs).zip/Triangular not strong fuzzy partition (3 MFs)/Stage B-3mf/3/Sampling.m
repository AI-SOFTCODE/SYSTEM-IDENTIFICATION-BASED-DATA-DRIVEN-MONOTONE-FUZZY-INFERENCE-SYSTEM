clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
% b = [0.0396    0.0699    0.5000
%     0.0266    0.0807    0.0836
%     0.0703    0.0911    0.0983];

%train 2

 % b=[0.0358    0.0837    0.5000
 %    0.0282    0.0792    0.0753
 %   -0.1462    0.0946    0.0944];


% %train 3
% 
 % b=[0.0410    0.0711    0.5000
 %    0.0264    0.0823    0.0977
 %    0.0605    0.0940    0.0893];

%train 4
% 
  b=[0.0443    0.0754    0.5000
    0.0249    0.0800    0.0765
    0.1657    0.0936    0.0796];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end