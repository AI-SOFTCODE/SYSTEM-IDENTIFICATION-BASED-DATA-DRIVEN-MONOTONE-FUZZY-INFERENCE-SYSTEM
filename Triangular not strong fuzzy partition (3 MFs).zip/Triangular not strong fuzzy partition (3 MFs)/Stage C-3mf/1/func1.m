% a function used to generate Eq. (9)
function y = func1(b,lambda)

global ICONSTR RK

b = b(:);
    
% Define the 16 target values for b:

% this is the b_update obtained from Stage B different training data set

% train data  1
 % c = [  0.0396
 %    0.0699
 %    0.5000
 %    0.0266
 %    0.0807
 %    0.0836
 %    0.0703
 %    0.0911
 %    0.0983];

% 2
%   c = [ 
%     0.0358
%     0.0837
%     0.5000
%     0.0282
%     0.0792
%     0.0753
%    -0.1462
%     0.0946
%     0.0944
% ];

% 3
%   c = [    0.0410
%     0.0711
%     0.5000
%     0.0264
%     0.0823
%     0.0977
%     0.0605
%     0.0940
%     0.0893
% ];

% 4
  c = [
     0.0443
    0.0754
    0.5000
    0.0249
    0.0800
    0.0765
    0.1657
    0.0936
    0.0796
  ];



%train data 2
%c is obtained from b_update stage B from train data 2

%train data 3
%c is obtained from b_update stage B from train data 2

%train data 4
%c is obtained from b_update stage B from train data 2

fuzzyrule_matrix=[1	1	0
2	1	0
3	1	0
1	2	0
2	2	0
3	2	0
1	3	0
2	3	0
3	3	0];

k=constraint(fuzzyrule_matrix);

fobj = (b - c)'*(b - c);
ICONSTR1=(k*[b])';

ICONSTR=ICONSTR1;

y = fobj+ (sum(lambda.* max([ICONSTR; -lambda./(2*RK)])) + sum(RK*(max([ICONSTR; -lambda./(2*RK)])).^2));