function [fuzziness,size_fuzziness,complete_fuzzyrule]=  fuzzymf(x)

mf1_x1 = trimf(x(1), [1 1 4]);%key in %trapmf %gaussmf %gbellmf
mf2_x1 = trimf(x(1), [2 5 8]);%key in
mf3_x1 = trimf(x(1), [7 13 13]);%key in

fuzziness{1,:} = [mf1_x1 mf2_x1 mf3_x1 ];%key in

mf1_x2 = trimf(x(2), [235 235 450]);%key in
mf2_x2 = trimf(x(2), [300 582.5 700]);%key in
mf3_x2 = trimf(x(2), [630 930 930]);%key in


fuzziness{2,:} = [mf1_x2 mf2_x2 mf3_x2 ];


size_fuzziness=[3,3]; %key in

complete_fuzzyrule=(combvec(1:3', 1:3')'); %key in