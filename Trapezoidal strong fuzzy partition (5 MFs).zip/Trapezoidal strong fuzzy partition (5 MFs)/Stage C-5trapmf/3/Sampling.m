clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
         b =[0.035 0.056 0.215 0.215 0.215  
             0.035 0.078 0.215 0.215 0.215  
             0.035 0.078 0.215 0.215 0.215  
             0.078 0.078 0.215 0.215 0.215  
             0.303 0.303 0.303 0.303 0.370]; %train 1
 
         % b= [0.034 0.070 0.147 0.271 0.348  
         %     0.034 0.077 0.147 0.271 0.348  
         %     0.034 0.077 0.147 0.271 0.348  
         %     0.034 0.077 0.147 0.271 0.348  
         %     0.271 0.271 0.271 0.271 0.370];%train 2

         % b= [0.037 0.061 0.142 0.207 0.207  
         %    0.037 0.077 0.142 0.207 0.207  
         %    0.037 0.077 0.142 0.207 0.207  
         %    0.062 0.077 0.142 0.207 0.207  
         %    0.346 0.346 0.346 0.346 0.370]; %train 3
 % 
 % b=[0.040 0.051 0.145 0.207 0.207  
 %    0.040 0.080 0.145 0.207 0.207  
 %    0.040 0.080 0.145 0.207 0.207  
 %    0.096 0.096 0.145 0.207 0.207  
 %    0.226 0.226 0.226 0.226 0.500]%train4

    out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end