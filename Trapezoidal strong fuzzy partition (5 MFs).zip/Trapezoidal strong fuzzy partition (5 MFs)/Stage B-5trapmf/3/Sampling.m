clc
clear
% Define ranges.
rangeSev = [1,13];
% Change the occurrence range to match the membership function domain.
rangeOcc = [235,930];

g = 0.1;
nSev = (rangeSev(2)-rangeSev(1))/g+1;
nOcc = (rangeOcc(2)-rangeOcc(1))/g+1;

s = linspace(rangeSev(1), rangeSev(2), nSev);
o = linspace(rangeOcc(1), rangeOcc(2), nOcc);

% Preallocate the output matrix.
out = zeros(nSev, nOcc);

parfor i = 1:nSev
    disp(i);
    for j = 1:nOcc
% %train 1
      b = [0.0418 0.0554 0.5000 0.5000 0.5000  
           0.0347 0.0849 0.2217 0.5000 0.3009  
           0.0279 0.0738 0.0892 0.1367 -0.4327  
           0.0837 0.0702 0.0862 0.0624 0.1187  
           0.5000 0.3312 0.2369 0.1431 0.3700];
%train 2

 % b=[0.0396 0.0693 0.1526 0.5000 0.5000  
 %    0.0345 0.0828 0.2529 0.5000 0.5000  
 %    0.0337 0.0725 0.0802 0.1074 0.4343  
 %    0.0282 0.0739 0.1031 0.0661 -0.0419  
 %    0.5000 0.1143 0.2198 0.1586 0.3700];


% %train 3

% b=[0.0440 0.0612 0.1973 0.5000 0.5000  
%    0.0338 0.0805 0.1817 0.5000 0.2967  
%    0.0340 0.0788 0.0926 0.1203 -0.4248  
%    0.0621 0.0714 0.0949 0.0576 0.1072  
%    0.5000 0.5000 0.2343 0.1498 0.3700];

%train 4
% 
 % b=[0.0563 0.0511 0.1894 0.5000 0.5000
 %    0.0277 0.0846 0.2144 0.5000 0.2929
 %    0.0369 0.0766 0.0739 0.1094 -0.4183
 %    0.1146 0.0773 0.1031 0.0705 0.1006
 %    0.5000 0.0461 0.2504 0.1075 0.5000];


   out(i,j) = FISHFIS(s(i),o(j),b);
    end
end

switch g
   case 0.1
      save("FISH01.mat", "out", "g");

end